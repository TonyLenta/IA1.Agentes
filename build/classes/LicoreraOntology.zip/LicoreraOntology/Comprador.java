/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package LicoreraOntology;


import jade.core.Agent;
import jade.core.AID;
import jade.lang.acl.ACLMessage;
import jade.proto.AchieveREInitiator;
import jade.domain.FIPANames;
import java.util.Scanner;
 
 
public class Comprador extends Agent {
 
    protected void setup()
    {
        Object[] args = getArguments();
        if (args != null && args.length > 0) {
            System.out.println("Entrandor a licoreria! Solicitando licor a la tienda");
            ACLMessage msg = new ACLMessage(ACLMessage.REQUEST);
            for (int i = 0; i < args.length; ++i)
                msg.addReceiver(new AID((String) args[i], AID.ISLOCALNAME));
            msg.setProtocol(FIPANames.InteractionProtocol.FIPA_REQUEST);
            msg.setContent("licor");
 
            addBehaviour(new ManejadorInitiator(this,msg));
 
        }
        else System.out.println("Debe de esribir el nombre de un vendedor como minimo (pasado como parametro).");
    }
 
    class ManejadorInitiator extends AchieveREInitiator
    {
        public ManejadorInitiator(Agent a,ACLMessage msg) {
            super(a,msg);
        }
 
        protected void handleAgree(ACLMessage agree)
        {
          
            System.out.println("vendedor " + agree.getSender().getName()
                    + " informa que han salido a atender al cliente.");
        }
 
        protected void handleRefuse(ACLMessage refuse)
        {
                      
            System.out.println("vendedor " + refuse.getSender().getName()
                    + " responde que el cliente no cumple con la mayoria de edad para comprar licor. No podremos atenderte!!!");
        }
 
        protected void handleNotUnderstood(ACLMessage notUnderstood)
        {
            
             System.out.println ("Por favor introduzca edad:");

       int edad;

        Scanner teclado = new Scanner(System.in);

        
        edad = teclado.nextInt();

        if (edad>=18){     
        
        
             System.out.println ("Por favor introduzca nombre de licor:");

        String entradaTeclado = "";

        Scanner entradaEscaner = new Scanner (System.in); //Creación de un objeto Scanner

        entradaTeclado = entradaEscaner.nextLine (); //Invocamos un método sobre un objeto Scanner

        System.out.println ("Cliente solisita licor llamdo \"" + entradaTeclado +"\"");
            System.out.println("vendedor " + notUnderstood.getSender().getName()
                    + " el licor esta disponible.");
            System.out.println("Botella de cuanto litros desea compra ?");
             String entradaTeclado2 = "";
             entradaTeclado2 = entradaEscaner.nextLine ();         
            System.out.println("vendedor " + notUnderstood.getSender().getName()
                    + " gracias por preferirnos, vuelva pronto.");
             
        }else
        {
            System.out.println("Cliente no cumple la mayoria de edad");
        }

            
            
        }
 
        protected void handleInform(ACLMessage inform)
        {
            System.out.println("vendedor " + inform.getSender().getName()
                    + " informa que han atendido al cliente.");
        }
 
        protected void handleFailure(ACLMessage fallo)
        {
            if (fallo.getSender().equals(myAgent.getAMS())) {
                System.out.println("Algunos licores no estan en stock");
            }
            else
            {
                System.out.println("Fallo en el vendedor " + fallo.getSender().getName()
                        + ": " + fallo.getContent().substring(1, fallo.getContent().length()-1));
            }
        }
    }
 
}

