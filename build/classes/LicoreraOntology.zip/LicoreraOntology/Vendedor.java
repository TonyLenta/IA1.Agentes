
package LicoreraOntology;


import jade.content.lang.Codec;
import jade.content.lang.sl.SLCodec;
import jade.content.onto.Ontology;
import java.util.StringTokenizer;
import jade.core.Agent;
import jade.lang.acl.ACLMessage;
import jade.lang.acl.MessageTemplate;
import jade.proto.AchieveREResponder;
import jade.domain.FIPANames;
import jade.domain.FIPAAgentManagement.NotUnderstoodException;
import jade.domain.FIPAAgentManagement.RefuseException;
import jade.domain.FIPAAgentManagement.FailureException;
import ontologias.Policia.PoliciaOntology;
 
 
public class Vendedor extends Agent {
 
    private Codec codec = new SLCodec();
    private Ontology ontologia = LicoreriaOntologia.getInstance();
        
    public double EDAD;
 
    protected void setup()
    {
        EDAD=(Math.random()*10);
        System.out.println("Vendedor "+getLocalName()+": Esperando a clientes...");
        MessageTemplate protocolo = MessageTemplate.MatchProtocol(FIPANames.InteractionProtocol.FIPA_REQUEST);
        MessageTemplate performativa = MessageTemplate.MatchPerformative(ACLMessage.REQUEST);
        
          MessageTemplate plantilla = MessageTemplate.and(protocolo, performativa);
 
         MessageTemplate lenguajeContenido = MessageTemplate.MatchLanguage(codec.getName());
        MessageTemplate ontoTemplate = MessageTemplate.MatchOntology(ontologia.getName());
       // MessageTemplate plantilla = MessageTemplate.and(MessageTemplate.and(protocolo, performativa), MessageTemplate.and(lenguajeContenido, ontoTemplate));
        
        
         getContentManager().registerLanguage(codec);
        getContentManager().registerOntology(ontologia);

        addBehaviour(new ManejadorResponder(this, plantilla));
    }
 
    class ManejadorResponder extends AchieveREResponder
    {
        public ManejadorResponder(Agent a,MessageTemplate mt) {
            super(a,mt);
        }
 
        protected ACLMessage handleRequest(ACLMessage request)throws NotUnderstoodException, RefuseException
        {
            //System.out.println("Hospital "+getLocalName()+": Hemos recibido una llamada de " + request.getSender().getName() + " diciendo que ha visto un accidente.");
            
            System.out.println("vendedor "+getLocalName()+": Hemos atendido al cliente " + request.getSender().getName() + " diciendo que solicita licor.");
            StringTokenizer st=new StringTokenizer(request.getContent());
            String contenido=st.nextToken();
            if(contenido.equalsIgnoreCase("licor."))
            {
                st.nextToken();
                int edad=Integer.parseInt(st.nextToken());
                if (edad>EDAD)
                {
                    System.out.println("vendedor "+getLocalName()+": Atendiendo al cliente!!!");
                    ACLMessage agree = request.createReply();
                    agree.setPerformative(ACLMessage.AGREE);
                    return agree;
                }
                else
                {
                    System.out.println("vendor "+getLocalName()+": No eres mayor de edad. No podremos atenderte!!!");
                    throw new RefuseException("No cumple con la mayoria de edad");
                }
            }
            else throw new NotUnderstoodException("vendedor manda un mensaje que no puedo entender.");
        }
 
        protected ACLMessage prepareResultNotification(ACLMessage request,ACLMessage response) throws FailureException
        {
            if (Math.random() > 0.2) {
                System.out.println("vendedor "+getLocalName()+": Ha vuelto atender al cliente.");
                ACLMessage inform = request.createReply();
                inform.setPerformative(ACLMessage.INFORM);
                return inform;
            }
            else
            {
                System.out.println("vendedor "+getLocalName()+": entregando licor al cliente.");
                throw new FailureException("Gracias por preferirnos, vuelva pronto..");
            }
        }
    }
}

