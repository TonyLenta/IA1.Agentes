/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ontologias.policia.predicados;

import ontologias.policia.conceptos.TiempoLlegada;

/**
 *
 * @author tony_
 */
public class Disponible {
    
    
    private TiempoLlegada TIEMPO ;

    public TiempoLlegada getTIEMPO() {
        return TIEMPO;
    }

    public void setTIEMPO(TiempoLlegada TIEMPO) {
        this.TIEMPO = TIEMPO;
    }
    
}
