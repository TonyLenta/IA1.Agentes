/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ontologias.policia.predicados;

import ontologias.policia.conceptos.Motivo;

/**
 *
 * @author tony_
 */
public class NoDisponible {
    
    private Motivo MOTIVO;

    public Motivo getMOTIVO() {
        return MOTIVO;
    }

    public void setMOTIVO(Motivo MOTIVO) {
        this.MOTIVO = MOTIVO;
    }
}
